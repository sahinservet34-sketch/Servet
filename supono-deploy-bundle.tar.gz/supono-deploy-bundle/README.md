# Supono's – Tek Tık DigitalOcean Kurulum Paketi

Bu paket, gönderdiğin **supono-react-dev-ready** projesini **PostgreSQL** veritabanı ile, dahili **Admin Paneli** ve tüm görselleriyle birlikte **tek komutla** ayağa kaldırmak için hazırlandı. Amaç: **stabil**, **hızlı** ve **basit**.

## İçerik
- `docker-compose.yml` – Uçtan uca servisler: `db` (Postgres), `app` (Node/Vite prod), `pgadmin` (opsiyonel GUI)
- `Dockerfile.prod` – Üretim için çok-aşamalı Node 20 Alpine imajı
- `.env` – Parolalar ve gizli anahtarlar (doldurmanız gerekir)
- `deploy.sh` – Yepyeni bir DigitalOcean droplet’inde Docker’ı kurup projeyi kaldıran script

> **Not:** Projedeki **görseller** `client/public` içinden build sırasında **`client/dist`** klasörüne gömülür. Admin panelinden yaptığınız veri değişiklikleri **PostgreSQL**’de tutulur. Konteyner yeniden başlasa bile **veritabanı kalıcıdır** (Docker volume).

---

## 1) DigitalOcean – Hangi droplet?
En hızlı ve stabil yol: **Marketplace → “Docker (Ubuntu 22.04)”** imajlı bir droplet seçin.
- Plan: 1–2 vCPU / 1–2 GB RAM başlangıç için yeterli
- Bölge: size en yakın (Seattle/NYC vb.)
- SSH veya root şifre ile erişim

> İsterseniz standart Ubuntu da olur; `deploy.sh` zaten Docker kurulumunu otomatik yapıyor.

---

## 2) Sunucuya dosyaları atın
Sunucunuza bağlanıp bu klasörü (ve uygulama kaynaklarını) kopyalayın:
```bash
scp -r . root@YOUR_DROPLET_IP:/opt/supono
```

> Alternatif: Droplet’te `git clone` yapıp bu **deploy paketi** dosyalarını proje köküne koyun.

---

## 3) .env doldurun
Sunucuda:
```bash
cd /opt/supono
cp .env .env.local
nano .env.local
```
Şu alanları güncelleyin:
- `POSTGRES_PASSWORD` (güçlü bir parola)
- `SESSION_SECRET` (uzun rastgele bir dize)
- `PGADMIN_EMAIL` ve `PGADMIN_PASSWORD` (opsiyonel arayüz için)

> `docker-compose.yml` otomatik olarak `POSTGRES_PASSWORD` ile `DATABASE_URL`’ü bağlar.

---

## 4) Tek komutla kur
```bash
bash deploy.sh
```
Bu komut şunları yapar:
1. Docker ve Docker Compose’u kurar (gerekirse).
2. `docker compose up -d --build` ile **db**, **app**, **pgadmin** servislerini ayağa kaldırır.

---

## 5) Erişim
- Site: `http://YOUR_DROPLET_IP/`  (80 → 5000 yönlendirmesi, tek servis)
- API/Health: `http://YOUR_DROPLET_IP:80/api/health`
- PgAdmin (opsiyonel): `http://YOUR_DROPLET_IP:5050/`

PgAdmin içinde yeni sunucu eklerken:
- Host: `db`
- Port: `5432`
- User: `suponos_user`
- Password: `.env` içindeki `POSTGRES_PASSWORD`
- Database: `suponos`

---

## 6) İlk veri ve görseller
- **Görseller**: Build ile `client/dist` içine paketlenir. Ekstra bir şey yapmanıza gerek yok.
- **Örnek veri**: Drizzle migration/seed komutları kullanacaksanız (varsa) burada çalıştırın:
  ```bash
  docker compose exec app bash -lc "npm run db:push"
  ```
  ya da PgAdmin ile tablo ve kayıtlarınızı içe aktarın.

---

## 7) Log ve güncelleme
- Uygulama logları: `./logs` klasöründe tutulur.
- Yeni sürüm yayınlamak için:
  ```bash
  git pull   # veya dosyaları güncelleyin
  docker compose build app
  docker compose up -d
  ```

---

## 8) HTTPS (opsiyonel hızlı kurulum)
Hızlıca HTTPS isterseniz, Droplet IP’nize bir domain yönlendirin ve **Caddy** reverse proxy ya da **nginx + certbot** ekleyelim. İsterseniz ikinci bir paket hazırlayabilirim.

---

**Tarih:** 2025-09-03