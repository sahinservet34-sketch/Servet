#!/usr/bin/env bash
set -euo pipefail

# 1) Docker kurulu mu?
if ! command -v docker >/dev/null 2>&1; then
  echo "[*] Docker kuruluyor..."
  apt-get update -y
  apt-get install -y ca-certificates curl gnupg
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo     "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu     $(. /etc/os-release && echo "$VERSION_CODENAME") stable" |     tee /etc/apt/sources.list.d/docker.list > /dev/null
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

# 2) Proje dizini
cd "$(dirname "$0")"

# 3) .env var mı?
if [ ! -f ".env.local" ] && [ ! -f ".env" ]; then
  echo "[-] .env dosyası bulunamadı! Lütfen .env veya .env.local oluşturun."
  exit 1
fi

# Compose için .env tercih sırası
if [ -f ".env.local" ]; then
  export $(grep -v '^#' .env.local | xargs)
else
  export $(grep -v '^#' .env | xargs)
fi

echo "[*] Servisler ayağa kaldırılıyor..."
docker compose up -d --build

echo "[+] Kurulum tamam. Ulaşım: http://$(curl -s ifconfig.me)/"